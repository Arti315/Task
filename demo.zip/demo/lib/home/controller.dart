import 'dart:ui';

import 'package:demo/home/bottomScreen.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../apiServices/api.dart';
import '../model/homeModel.dart';
import '../model/userdetails.dart';

class HomeController extends GetxController {
  RxList<homeModel> userList = <homeModel>[].obs;
  UserDetailsModel userDetailsModel = UserDetailsModel();
  RxBool loader = true.obs;
  @override
  void onInit() {
    getlListApi();
    super.onInit();
  }

  onTapBottom(coloridx) {}

  getlListApi() async {
    await ApiClient().getUser().then((value) {
      if (value != null) {
        print(">>>>>>>>>>>>>>>>>>>>value $value");
        Iterable iterable = value;
        userList.value = iterable.map((e) => homeModel.fromJson(e)).toList();
        print(">>>>>>>>>>>>>>>>${userList[0].title}");
        update();
      }
    });
  }

  getUserApi(String id, Color? colorss) async {
    await ApiClient().getUserDetails(id).then((value) {
      if (value != null) {
        loader.value == false;
        print(">>>>>>>>>>>>>>>>>>>>value $value");
        userDetailsModel = UserDetailsModel.fromJson(value);
        print(">>>>>>>>>>>>>>>>${userDetailsModel.title}");
        Get.bottomSheet(
            BottomsheetScreen(
                Get.put(
                  HomeController(),
                ),
                colorss!,
                userDetailsModel),
            isScrollControlled: true);
        update();
      }
    });
  }
}
