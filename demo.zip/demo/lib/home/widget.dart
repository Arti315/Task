import 'package:demo/home/controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../model/homeModel.dart';

class ItemWidget extends StatelessWidget {
  homeModel userModel;
  int index;

  ItemWidget(this.userModel, this.index, {super.key});

  var controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          controller.loader == true;
          controller.getUserApi(userModel.id.toString(),
              index % 2 == 0 ? Colors.green[300] : Colors.cyan[200]);
        },
        child: Padding(
            padding: EdgeInsets.only(left: 10, top: 10, bottom: 0, right: 10),
            child: Card(
                color: index % 2 == 0 ? Colors.green[300] : Colors.cyan[200],
                // shadowColor: Colors.amber,
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text.rich(TextSpan(
                          style: TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                          children: [
                            TextSpan(text: "Title:-  "),
                            TextSpan(
                                text: userModel.title,
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal)),
                          ])),
                      Text.rich(TextSpan(
                          style: TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                          children: [
                            TextSpan(text: "Body:-  "),
                            TextSpan(
                                text: userModel.body?.replaceAll("\n", ""),
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal)),
                          ])),
                    ],
                  ),
                ))));
  }
}
