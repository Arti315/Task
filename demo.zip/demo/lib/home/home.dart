import 'package:demo/home/controller.dart';
import 'package:demo/home/widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';

import '../model/homeModel.dart';

class HomeScreen extends GetWidget<HomeController> {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
        init: HomeController(),
        builder: (con) {
          return Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.cyan[200],
                leading: BackButton(onPressed: () {}, color: Colors.black),
                title: Text("Details"),
              ),
              body: Obx(
                () => ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (
                    context,
                    index,
                  ) {
                    return SizedBox();
                  },
                  itemCount: con.userList.length,
                  itemBuilder: (context, index) {
                    homeModel userListModel = con.userList[index];
                    return ItemWidget(userListModel, index);
                  },
                ),
              ));
        });
  }
}
