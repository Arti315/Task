import 'package:get/get_navigation/src/routes/get_route.dart';

import '../home/binding.dart';
import '../home/home.dart';

class AppRoutes {
  static const String homeScreen = '/Home_Screen';

  static List<GetPage> pages = [
    GetPage(
      name: homeScreen,
      page: () => const HomeScreen(),
      bindings: [
        HomeBinding(),
      ],
    ),
  ];
}
