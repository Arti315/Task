import 'dart:convert';
import 'package:get/get_connect/connect.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_disposable.dart';
import 'package:http/http.dart' as http;

class ApiClient extends GetConnect implements GetxService {
  //////////////////////////// Api Get //////////////////////////////////////////
  Future getUser() async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    var baseUrl = "https://jsonplaceholder.typicode.com/posts";
    http.Client client = http.Client();
    var response = await client.get(Uri.parse(baseUrl), //your address here
        headers: headers);
    if (response.statusCode == 200) {
      print(">>>>>>>>>>>>>>>>>hit Api>>>>>>>>>>>>>>");
      final responseData = jsonDecode(response.body);
      return responseData;
    } else {
      return jsonDecode(response.body);
    }
  }

//////////////////////////// Api Get User Details //////////////////////////////////////////
  Future getUserDetails(String userId) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    var baseUrl = "https://jsonplaceholder.typicode.com/posts/$userId";
    http.Client client = http.Client();
    var response = await client.get(Uri.parse(baseUrl), //your address here
        headers: headers);
    if (response.statusCode == 200) {
      print(">>>>>>>>>>>>>>>>>hit Apiuser Details>>>>>>>>>>>>>>");
      final responseData = jsonDecode(response.body);
      return responseData;
    } else {
      return jsonDecode(response.body);
    }
  }
}
